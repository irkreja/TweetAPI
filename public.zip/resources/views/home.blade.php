@extends('layouts.app')

@section('content')
    <timeline></timeline>
@endsection
